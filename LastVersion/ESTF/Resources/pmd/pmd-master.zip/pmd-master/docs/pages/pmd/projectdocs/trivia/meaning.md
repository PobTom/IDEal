---
title: What does 'PMD' mean?
permalink: pmd_projectdocs_trivia_meaning.html
author: David Dixon-Peugh
---

We've been trying to find the meaning of the letters PMD - because frankly, we don't
really know.  We just think the letters sound good together.

However, in the spirit of the Computing Industry, we have come up with several "backronyms" to explain it.

**PMD...**

*   Pretty Much Done
*   Project Mess Detector
*   Project Monitoring Directives
*   Project Meets Deadline
*   Programming Mistake Detector
*   Pounds Mistakes Dead
*   PMD Meaning Discovery (recursion, hooray!)
*   Programs of Mass Destruction
*   Programming Meticulous coDe
*   [A 'Chaotic Metal' rock band name](http://www.myspace.com/prettymarydies)
