bundle install --path vendor/bundle
bundle update
bundle exec jekyll build
