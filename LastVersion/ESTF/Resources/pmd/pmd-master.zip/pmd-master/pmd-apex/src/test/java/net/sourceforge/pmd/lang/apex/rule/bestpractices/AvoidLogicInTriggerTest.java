/**
 * BSD-style license; for more info see http://pmd.sourceforge.net/license.html
 */

package net.sourceforge.pmd.lang.apex.rule.bestpractices;

import net.sourceforge.pmd.testframework.PmdRuleTst;

public class AvoidLogicInTriggerTest extends PmdRuleTst {
    // no additional unit tests
}
