<!-- Please, prefix the report title with the language it applies to within brackets, such as [java] or [apex].
If not specific to a language, you can use [core]. -->

<!-- NB: issues about the rule designer should be opened at https://github.com/pmd/pmd-designer/issues -->

**Affects PMD Version:** 

**Rule:**

**Description:**

**Code Sample demonstrating the issue:**

```

```

**Running PMD through:** *[CLI | Ant | Maven | Gradle | Designer | Other]*

<!-- If relevant, also include your JDK and OS information, e.g. for ClassNotFoundException, LinkageError, reflection failures, etc. -->
