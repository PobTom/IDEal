package com.google.checkstyle.test.chapter5naming.rule521packageNamesCamelCase; //warn
final class InputPackageNameBad {}
